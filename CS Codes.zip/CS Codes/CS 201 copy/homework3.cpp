/*
 Name: Thomas Gray
 Email: tcgray2@crimson.ua.edu
 Course Section: Fall 2024 CS 201
 Homework #: 3
 To Compile: <Run in terminal with g++ -std=c++17 homework3.cpp>
 To Run: <After you run that in the terminal run ./a.out dbfile1.txt query.txt //or whatever input file the code will be reading in from>
 It outputs to a created file called output.txt
*/
#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <unordered_map>
#include <chrono>

//A search function to search both maps, and output the movies or actors pertaing to the input
void Search(const std::unordered_map<std::string, std::vector<std::string>>& movieAndActors, 
const std::unordered_map<std::string, std::vector<std::string>>& actorsAndMovie,
const std::string& name, std::ofstream& outputFile){
    //If it is a movie
    //finds the movie name and makes an iterator to iterate through the list of actors names
    auto It = movieAndActors.find(name);
    if(It != movieAndActors.end()){
        outputFile << "Movie Name: " << name << std::endl;
        outputFile << "  Actors in: " << name << std::endl;
        for(const auto & actors : It->second){
            outputFile << "     " << actors << std::endl;
        }
        return;
    }

    //If it is an actor
    It = actorsAndMovie.find(name);
    if(It != actorsAndMovie.end()){
        outputFile << "Actor Name: " << name << std::endl;
        outputFile << "  Movies " << name  << " Acted in" << std::endl;
        for(const auto & movies : It->second){
            outputFile << "     " << movies << std::endl;
        }
        return;
    }

    //If it is not found in either list
    outputFile << "Nothing Found - No Results For: " << name << std::endl;
    return;
}

int main(int argc, char *argv[]){
    //To check how long the program takes
	auto starttime = std::chrono::steady_clock::now();
    int i = 0;
	// check for correct command-line arguments
    //from the sample file given
	if (argc != 3) {
	   std::cout << "Usage: " << argv[0] << " <db file> <query file>" << std::endl;
	   std::exit(-1);
	}

	std::string line, name;
	std::regex delim("/");
	std::ifstream dbfile(argv[1]);
	if (!dbfile.is_open()) {
	   std::cout << "Unable to open file: " << argv[1] << std::endl;
	   std::exit(-1);
	}
    //To time the data structure creation
    auto starttime1 = std::chrono::steady_clock::now();
    //I decided to use an unorderd_map as my data structure as I feel this is the easiest way to store two different types of variable inputs
    std::unordered_map<std::string, std::vector<std::string>> movieAndActors; //sets movie and list of actors to <key, value>
    //I made two unordered maps, so I can easily look up the actors in a movie, and the movie actors acted in
    std::unordered_map<std::string, std::vector<std::string>> actorsAndMovies; //sets actor and list of movies to <key, value>

	std::cout << "***Reading db file " << argv[1] << "***" << std::endl;
	while (std::getline(dbfile, line)) {
	   // parse each line for tokens delimited by "/"
	   auto begin = std::sregex_token_iterator(line.begin(), line.end(), delim, -1);
	   auto end = std::sregex_token_iterator();
	   //std::cout << "***Line " << ++i << " ***" << std::endl;
	   //std::cout << "Movie:\t" << *begin << std::endl;
       std::string movie = *begin;
	   ++begin;
	   //std::cout << "Actors: " << std::endl;
	   for (std::sregex_token_iterator word = begin; word != end; ++word) {
		//std::cout << "\t" << *word << std::endl;
        //Adds all the actors that acted in the particular movie and sets it as its value, ie <key, value> in this case <movie, actors>
        movieAndActors[movie].push_back(*word);
        //Adds all the movies a particular actor acted in and sets the movies as the value for the key(actor)
        actorsAndMovies[*word].push_back(movie);
	   }
	}
    //Shows how much time it takes to create the data structure
    auto endtime1 = std::chrono::steady_clock::now();
	std::chrono::duration<double> timetaken1 = endtime1 - starttime1;


	dbfile.close();
	std::cout << "***Done reading db file " << argv[1] << "***" << std::endl;

	std::ifstream queryfile(argv[2]);
	if (!queryfile.is_open()) {
	   std::cout << "Unable to open file: " << argv[2] << std::endl;
	   std::exit(-1);
	}

	std::cout << "***Reading query file " << argv[2] << "***" << std::endl;

    //Creates an output file for easier viewing
   std::ofstream outputFile("output.txt");
      if(!outputFile){
         std::cout << "Unable to create output file." << std::endl;
         return 1;
      }

    //Creates a new timer to time to track how long the search takes
    auto starttime2 = std::chrono::steady_clock::now();

	while (std::getline(queryfile, name)) {
	   //std::cout << name << std::endl;
       //Uses the search function to search the queryfile
       Search(movieAndActors, actorsAndMovies, name, outputFile);
	}
    outputFile.close();
    //Timer for search
    auto endtime2 = std::chrono::steady_clock::now();
    std::chrono::duration<double> timetaken2 = endtime2 - starttime2;

	queryfile.close();
	std::cout << "***Done reading query file " << argv[2] << "***" << std::endl;

    //Timer for total time
    auto endtime = std::chrono::steady_clock::now();
    std::chrono::duration<double> timetaken = endtime - starttime;


    //Outputs how long it took to output the data structure
    std::cout << "Time to create data structure: " << timetaken1.count() << std::endl;

    //Outputs how long it took to search
    std::cout << "Time to search: " << timetaken2.count() << std::endl;

    //Outputs the total time
    std::cout << "Total time: " << timetaken.count() << std::endl;

	return 0;
}