#include <iostream>
#include <array>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>
#include <chrono>

//Using the templete from the Hw pdf
template< class RandomIt >
constexpr void insertionSort(RandomIt first, RandomIt last){
    for(auto j = first; (j+1) != last; j++){ 
        //The number after first in the array, and this is also how j will be used to iterate through the list.
        auto next = j + 1;
        auto key = *next;

        //We make i our iterator her for the array
        auto i = j;
        while(i >= first  && *i > key){
            //Derefrenced so the actual values are switched over, switches over the value to the right
            *(i + 1) = *i;
            i = i-1;
        }
        //puts the key into the right position.
        *(i+1) = key;
    }
}
int main(int argc, char *argv[]) {

	//std::cout << "Problem Size\tTime Taken (seconds)" << std::endl;
	std::cout << "Problem Size\tstd::sort Time (seconds)\tMerge Sort Time (seconds)" << std::endl;

	for (int size = 10; size <= 100000000; size *= 10) {
	
		int *a = new int[size];
	
		std::generate(a, a+size, std::rand);
		std::vector<int> temp(size + 1);
		auto starttime = std::chrono::steady_clock::now();
		insertionSort(a, a+size);
		auto endtime = std::chrono::steady_clock::now();
		std::chrono::duration<double> timetaken = endtime - starttime;
		std::cout << size << "\t" << timetaken.count() << std::endl;

		// std::vector<int> b(size);
        // std::generate(b.begin(), b.end(), std::rand);
        // std::vector<int> temp(size + 1);  // Temporary array for mergeSort

        // // Test mergeSort
        // auto starttime = std::chrono::steady_clock::now();
        // mergeSort(b.begin(), b.end(), temp.begin());
        // auto endtime = std::chrono::steady_clock::now();
        // std::chrono::duration<double>timetaken = endtime - starttime;
        // std::cout << size << "\t" << timetaken.count() << std::endl;

		//delete[] a;

	}

	return 0;
}
