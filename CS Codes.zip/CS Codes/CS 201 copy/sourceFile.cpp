/*
 Name: Thomas Gray
 Email: tcgray2@crimson.ua.edu
 Course Section: Fall 2024 CS 201
 Homework #: 1
 To Compile: <Run in terminal with g++ -std=c++17 sourceFile.cpp>
 To Run: <After you run that in the terminal run ./a.out input1.txt or whatever input file the code will be reading in from>
*/

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <unordered_map>
#include <chrono>

int main(int argc, char *argv[]) {
   auto starttime = std::chrono::steady_clock::now();
   //Doesn't run the code if the command line arguments aren't valid
   if(argc !=2){
      std::cout<<"Invalid number of arguments"<<std::endl;
      return 1;
   }
   //Stops the code if the file cannot open
   std::string input = argv[1];
   std::ifstream file(input);
      if(!file){
         std::cout << "Unable to open :" << input << std::endl;
      return 1;
      }

   std::string text;

   //Using a unorderded_map to hold the count aka the amount of times the word appears in the code while we read it in from the file.
   //Also since their are a lot of elements in the input files we use an unordered_map versus a regular map as it does't care about the order and will be faster.
   std::unordered_map<std::string, int> wordAndCount; 
   while (file >> text) {
      wordAndCount[text]++; // Increases the count whenever a duplicate of a word appears
   }

   std::vector<std::pair<std::string, int>> temp; //Made so we can copy over the elements of the unordered_map and sort them.
   for(auto i = wordAndCount.begin(); i != wordAndCount.end(); i++ ){
         temp.push_back(*i); //From sample code, copies over the key & value from the wordAndCount map whic in this case is the word and the count.
   }

   //How the sort function will compare the elements it is sorting
   auto lambdaTempSort = [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
      if (a.second > b.second) { //checks which count is bigger
         return true; 
      }
      else if(a.second < b.second){
         return false;
      }
      else{
         if(a.first < b.first){ //If the count is the same checks and compares the words to see which one comes first in alphabetical order
            return true;
         }
         else{
            return false;
         }
      }
   };

   std::sort(temp.begin(), temp.end(), lambdaTempSort);

   file.close();


   //Had to create an output file to show the output because the terminal wasn't capturing it all for input 2 & 3
   std::ofstream outputFile("output.txt");
      if(!outputFile){
         std::cout << "Unable to create output file." << std::endl;
         return 1;
      }

   for (const auto & str : temp) {
      outputFile << str.first << ": " << str.second << std::endl;
   }
   outputFile.close();

   //count the time taken
	auto endtime = std::chrono::steady_clock::now();
	std::chrono::duration<double> timetaken = endtime - starttime;
	std::cout << timetaken.count() << std::endl;

   return 0;
}