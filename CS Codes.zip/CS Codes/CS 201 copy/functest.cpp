#include <iostream>
#include <array>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>


/*
 Name: Thomas Gray
 Email: tcgray2@crimson.ua.edu
 Course Section: Fall 2024 CS 201
 Homework #: 0
*/
template< class RandomIt >
constexpr void merge(RandomIt first, RandomIt midpoint, RandomIt last, RandomIt tempstart) {
    //Helps find the data type of the variable to be able use infinity in the temparary arrays
     //Finds the distance between first and the midpoint as well as midpoint and last which will be used for n1, and n2
    int n1 = 0, n2 = 0;
    for(auto i = first; i!=midpoint; i++){
        n1++;
    }
    for(auto i = midpoint; i!=last; i++){
        n2++;
    }

    //creates temp arrays
    auto L = tempstart; 
    auto R = tempstart + n1;
  
   
   //Copies over the orginal arrays into the temp arrays

    for (int i = 0; i < n1; i++) {
        *(L + i) = *(first + i);
    }

    for (int j = 0; j < n2; j++) {
        *(R + j) = *(midpoint + j);
    }
    
    auto i = 0, j = 0; //first and second half

    for(auto k = first; k != last; k++){
        if(i < n1 && (j >= n2 || *(L + i) <= *(R + j))){//check index value then copy to orginal array
            *k = *(L + i);
            i++;
        }
        else{
            *k = *(R + j);
            j++;
        }
    }
}

template< class RandomIt >
constexpr void mergeSort (RandomIt first, RandomIt last, RandomIt tempstart){
    //Finding the size of the array
    int n = 0;
    for(auto i = first; i!=last; i++){
        n++;
    }
    if(n <= 1){
        return;
    }
    auto midpoint = first;
    for(auto i = 0; i < n/2; i++){
        midpoint++;
    }
    mergeSort(first, midpoint, tempstart); //1st half, upper bunk
    mergeSort(midpoint, last, tempstart + (n/2));//2nd half, lower bunk
    merge(first, midpoint, last, tempstart);
}


template< class RandomIt >
void print(RandomIt start, RandomIt end) {
	while (start != end) {
		std::cout << *start << " ";
		++start;
	}
	std::cout << std::endl;
}


int main(int argc, char *argv[]) {
	int a0[] = {56, 23, 11, 64, 43};
	std::array<int, 5> a1 = {5, 4, 3, 2, 1};
	std::array<std::string, 5> a2 = {"lion", "dog", "cat", "fox", "pig"};
	std::vector<double> v = {4.2, 3.1, 5.6, 2.8, 1.9};

	std::sort(a0, a0+5);
	print(a0, a0+5);

	std::sort(&a0[0], &a0[5]);
	print(&a0[0], &a0[5]);

	std::sort(a1.begin(), a1.end());
	print(a1.begin(), a1.end());

	std::sort(a2.begin(), a2.end());
	print(a2.begin(), a2.end());

	std::reverse(a2.begin(), a2.end());
	print(a2.begin(), a2.end());

	std::sort(a2.begin(), a2.end());
	print(a2.begin(), a2.end());

	std::sort(v.begin(), v.end());
	print(v.begin(), v.end());

	return 0;
}
