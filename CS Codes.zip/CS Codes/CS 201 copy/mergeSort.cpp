/*
 Name: Thomas Gray
 Email: tcgray2@crimson.ua.edu
 Course Section: Fall 2024 CS 201
 Homework #: 0
*/
#include <iostream>
#include <limits.h>
#include <algorithm>
#include <iterator>
#include <vector>

template< class RandomIt >
constexpr void merge(RandomIt first, RandomIt midpoint, RandomIt last, RandomIt tempstart) {
    //Finds the distance between first and the midpoint as well as midpoint and last which will be used for n1, and n2
    int n1 = 0, n2 = 0;
    for(auto i = first; i!=midpoint; i++){
        n1++;
    }
    for(auto i = midpoint; i!=last; i++){
        n2++;
    }

    //creates temp arrays
    auto L = tempstart; 
    auto R = tempstart + n1;
  
   
   //Copies over the orginal arrays into the temp arrays
    for (int i = 0; i < n1; i++) {
        *(L + i) = *(first + i);
    }

    for (int j = 0; j < n2; j++) {
        *(R + j) = *(midpoint + j);
    }
    
    auto i = 0, j = 0; //iterators for first and second half

    for(auto k = first; k != last; k++){
        //Checks if their are still elements left in L, and no more elements in R, 
        //as well as comparing the current item in in the letf and right side of the array
        if(i < n1 && (j >= n2 || *(L + i) <= *(R + j))){
            *k = *(L + i);
            i++;
        }
        else{
            *k = *(R + j);
            j++;
        }
    }
}

template< class RandomIt >
constexpr void mergeSort (RandomIt first, RandomIt last, RandomIt tempstart){
    //Finding the size of the array
    int n = 0;
    for(auto i = first; i!=last; i++){
        n++;
    }
    if(n <= 1){
        return;
    }
    auto midpoint = first;
    for(auto i = 0; i < n/2; i++){
        midpoint++;
    }
    mergeSort(first, midpoint, tempstart); //1st half, upper bunk
    mergeSort(midpoint, last, tempstart + (n/2));//2nd half, lower bunk
    merge(first, midpoint, last, tempstart);
}
