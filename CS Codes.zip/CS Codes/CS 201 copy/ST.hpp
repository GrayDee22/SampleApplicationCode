/*
 Name: Thomas Gray
 Email: tcgray2@crimson.ua.edu
 Course Section: Fall 2024 CS 201
 Homework #: 2
*/
#ifndef _ST_HPP_
#define _ST_HPP_

#include <utility>
#include <stack>
#include <vector>
#include <iostream>
#include "RBT.hpp"
#include "RBTPrint.hpp"
//Logic for a majority of my code for calling in functions from RBT.hpp and RBTPrint.hpp
//came from the displayTree function that was given, I mean the RedBlackTree<Key, Type>::


template <class Key, class Type>
class ST : public RedBlackTree<Key, Type> {
public:
	typedef RBTNode<Key, Type>* iterator;

	// Constructors
	// constant
	//Name from private:, a variable to count the nodes for me
	ST() { 
		nodeCount = 0;
	};

	// Destructor
	// linear in the size of the ST
	~ST(){
		clear();
	};

	// access or insert specifies element
	// inserts if the key is not present and returns a reference to
	// the value corresponding to that key
	// O(LogN), N size of ST
	Type& operator[](const Key& key) {
		auto node = RedBlackTree<Key, Type>::Search(key);
		//If node is in the tree, returns the value of the node
		if (node != nullptr) {
			return node->value; 
		}
		// If it isn't in the tree, it inserts it into the tree, searches it
		//to make sure its in the tree and return a pointer so we can return the value of the node
		else{
			RedBlackTree<Key, Type>::Insert(key, Type());
			node = RedBlackTree<Key, Type>::Search(key);
			return node->value; 
		}
	};

	// insert a (key, value) pair, if the key already exists
	// set the new value to the existing key
	// O(LogN), N size of ST
	void insert(const Key& key, const Type& value) {
		//Searches for the node in the Tree to see if it exists or not
		auto node = RedBlackTree<Key, Type>::Search(key);
		if(node != nullptr){
			node->value = value;
		}
		else{
			RedBlackTree<Key, Type>::Insert(key, value);
			//adds to the node count, once a new node has been inserted
			nodeCount++;
		}

	};

	// remove element at the given position
	// amortized constant
	void remove(iterator position) {
		//if the node is in the list removes it, and if its not nothing happens
		if(position != nullptr){
			if(RedBlackTree<Key, Type>::Remove(position->key)){
				nodeCount--;
			}
		}
	};

    // remove element with keyvalue key and 
	// return number of elements removed (either 0 or 1)
	// O(logN), N size of ST
	std::size_t remove(const Key& key) {
		if(RedBlackTree<Key, Type>::Remove(key)){
			nodeCount--;
			return 1;
		}
		else{
			return 0;
		}
	};

	// removes all elements from the ST, after this size() returns 0
	// linear in the size of the ST
	void clear() {
		// Use DeleteTree from RBT.hpp to delete all nodes
		RedBlackTree<Key, Type>::DeleteTree(RedBlackTree<Key, Type>::root);
		RedBlackTree<Key, Type>::root = nullptr; //After the tree is deleted, sets the root to a nullptr
		nodeCount = 0; // Puts the count back to 0 after the tree is deleted
	};

	// checks if ST has no elements; true is empty, false otherwise
	// constant
	bool empty() const {
		if(nodeCount == 0){
			return true;
		}
		else{
			return false;
		}
	};

	// returns number of elements in ST
	// constant
	std::size_t size() const {	
		return nodeCount;
	};

	// returns number of elements that match keyvalue key
	// value returned is 0 or 1 since keys are unique
	// O(LogN), N size of ST
	std::size_t count(const Key& key) {
		auto node = RedBlackTree<Key, Type>::Search(key);
		if(node != nullptr){
			return 1; 
		}
		else{
			return 0;
		}
	};

	// find an element with keyvalue key and return 
	// the iterator to the element found, nullptr if not found
	// O(LogN), N size of ST
	iterator find(const Key& key) {
		return RedBlackTree<Key, Type>::Search(key);
	};

	// check if key exists in ST
	// O(LogN), N size of ST
	bool contains(const Key& key) {
		auto node = RedBlackTree<Key, Type>::Search(key);
		if(node != nullptr){
			return true;
		}
		else{
			return false;
		}
	};

    // return contents of ST as a vector of (key,value) pairs
    // O(N), N size of ST
    std::vector<std::pair<Key, Type> > toVector() {
		std::vector<std::pair<Key, Type>> copy;
		//Makes a stack, to simulate in-order
		std::stack<RBTNode<Key, Type>*> stack;
		RBTNode<Key, Type>* it = RedBlackTree<Key, Type>::root;

		while (true) {
			while (it != nullptr) {
				stack.push(it); // Pushes the current(iterator) node to the stack
				it = it->left;  // Travels to the leftmost, as we need it to simulate inorder traversal
			}

			//If the stack is empty we can leave the code
			if(stack.empty()){
				break;
			}

			it = stack.top(); //sets the iterator to the top of the stack to iterate through the tree again
			stack.pop(); //removes that node from the stack so that it only gets visited once
			copy.emplace_back(it->key, it->value); //puts node's key and value in the vector

			it = it->right;

		}

		return copy;
    }

	// print the symbol table as Red-Black Tree
	// O(N), N size of ST
	void displayTree() {
		std::cout << RBTPrint<Key,Type>::TreeToString(RedBlackTree<Key,Type>::root) << std::endl;
	}

	// print the symbol table in sorted order
	// O(N), N size of ST
	void display() {
		//checks to see if the table is empty first
		if (empty()) {
        std::cout << "The table is empty" << std::endl;
        return;
    	}
		//Uses toVector, to copy over the elements as a vector so then we can print the ST table easier
		std::vector<std::pair<Key, Type>> copy = toVector();
    	for (const auto& node : copy) {
        	std::cout << node.first << ": " << node.second << std::endl;
    	}
	}

private:
	std::size_t nodeCount;
};

#endif

