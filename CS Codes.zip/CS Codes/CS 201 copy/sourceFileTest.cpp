#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <chrono>

int main(int argc, char *argv[]) {
    auto starttime = std::chrono::steady_clock::now();

    if (argc != 2) {
        std::cerr << "Invalid number of arguments" << std::endl;
        return 1;
    }

    std::string input = argv[1];
    std::ifstream file(input);
    if (!file) {
        std::cerr << "Unable to open: " << input << std::endl;
        return 1;
    }

    std::unordered_map<std::string, int> wordAndCount;
    std::string text;

    while (file >> text) {
        wordAndCount[text]++;
    }

    std::vector<std::pair<std::string, int>> temp(wordAndCount.begin(), wordAndCount.end());

    auto lambdaTempSort = [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
        return (a.second > b.second) || (a.second == b.second && a.first < b.first);
    };

    std::sort(temp.begin(), temp.end(), lambdaTempSort);
    file.close();

    // Output to a file instead of terminal
    std::ofstream outputFile("output.txt");
    if (!outputFile) {
        std::cerr << "Unable to create output file." << std::endl;
        return 1;
    }

    for (const auto& str : temp) {
        outputFile << str.first << ": " << str.second << std::endl;
    }
    outputFile.close();

    auto endtime = std::chrono::steady_clock::now();
    std::chrono::duration<double> timetaken = endtime - starttime;
    std::cout << "Time taken: " << timetaken.count() << " seconds" << std::endl;

    return 0;
}
