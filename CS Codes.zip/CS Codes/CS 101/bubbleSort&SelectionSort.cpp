// Bubble Sort

void BubbleSort(int arr[], int size) {
   for (int j = 1; j < size; j++) {
      bool isSorted = true;
      for (int i = 0; i < size-j; i++) {
         if (arr[i] > arr[i + 1]) {
            swap(arr[i], arr[i + 1])
            isSorted = false;
         }
      }
      if (isSorted) break;
   }
}

//Selection Sort
void SelectionSort(int arr[], int size) {
    for (int i = size-1; i > 0; i--) {
        int indexLargest = 0;
        for (int j = 1; j <= i; j++){
            if (arr[j] > arr[indexLargest]){
                indexLargest = j;
            }
        }
      swap(arr[indexLargest], arr[i]);
    }
}
/*
#include <iostream>
using namespace std;

void SelectionSort(int numbers[], int numbersSize) {
   int i;
   int j;
   int indexSmallest;
   int temp;      // Temporary variable for swap
   
   for (i = 0; i < numbersSize - 1; ++i) {
      
      // Find index of smallest remaining element
      indexSmallest = i;
      for (j = i + 1; j < numbersSize; ++j) {
         
         if ( numbers[j] < numbers[indexSmallest] ) {
            indexSmallest = j;
         }
      }
      
      // Swap numbers[i] and numbers[indexSmallest]
      temp = numbers[i];
      numbers[i] = numbers[indexSmallest];
      numbers[indexSmallest] = temp;
   }
}

int main() {
   int numbers[] = { 10, 2, 78, 4, 45, 32, 7, 11 };
   const int NUMBERS_SIZE = 8;
   int i;
   
   cout << "UNSORTED: ";
   for (i = 0; i < NUMBERS_SIZE; ++i) {
      cout << numbers[i] << ' ';
   }
   cout << endl;
   
   SelectionSort(numbers, NUMBERS_SIZE);
   
   cout << "SORTED: ";
   for (i = 0; i < NUMBERS_SIZE; ++i) {
      cout << numbers[i] << ' ';
   }
   cout << endl;
   
   return 0;
}
*/
