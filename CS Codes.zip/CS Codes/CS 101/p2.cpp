/*
1. Accept and store 4 command-line arguments

2. If argv[1] = i make sorting algorithm run for intergers (can make a function for int)
If it = s make sorting algorithm run for strings(can make function for strings)

3. The sorting algorithm has to be a stable mergesort. To do this we can use the code given in zybooks
& tweak it to sort by the index given in the sort file. 
ie 
You must implement an efficient O(n lg n) and stable sorting algorithm. 
Mergesort runs in O(n lg n) and can be easily implemented as stable. 
You can use the mergesort in ZyBooks. The ZyBook implements an unstable mergesort. 
To make it stable, modify the merge part of the sorting algorithm to take from the left subarray 
if the current left subarray item is <= the current right subarray item.

4. To compare in the sorting we are not to use <= for ints or strings but instead the index 
given in the sort file. If sort file is 0, 1 only compare and sort of those index values
if it doesn't have an index that another string or int has replace it with '\0' = null = 0;

5. If the datatype argument is "i", then write the sorted integers to the output file 
with each number appearing on a line, fixed right (right), with a column width of 10 (setw(10)).

6.
if argc is not 5: "Usage: ./a.out i|s sort_filename input_filename output_filename"
if datatype is not "i" or "s": "Invalid datatype \"" << datatype << "\" (must be \"i\" or \"s\")"
if sort file cannot be opened: "Unable to open sort file"
if input file cannot be opened: "Unable to open input file"
if output file cannot be opened: "Unable to open output file"
One way an output file will fail to open/create is if an invalid filename is used.
If multiple errors occur, only print one error in the priority listed above.

7. 
To extract the individual digits from an int, you can use the / and % operators. For example:

1234 % 10 = 4 and 1234 / 10 = 123
Then 123 % 10 = 3 and 123 / 10 = 12
Then 12 % 10 = 2 and 12 / 10 = 1
Then 1 % 10 = 1 and 1 / 10 = 0

*/

#include <iostream>
#include <fstream>
#include <cctype> 
#include <iomanip> 
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

void Merge(int numbers[], int index[], int idx, int i, int j, int k);
void MergeSort(int numbers[], int index[], int idx, int i, int k);
bool CompareInts(int index[], int idx, int left, int right);
//
void MergeString(string strings[], int index[], int idx, int i, int j, int k);
void MergeSortString(string strings[], int index[], int idx, int i, int k);
bool CompareStrings(int index[], int idx, string left, string right);

int main(int argc, char *argv[]){
    if(argc != 5){
        cout << "Usage: ./a.out i|s sort_filename input_filename output_filename" << endl;
        return -1;
    }

    string datatype = argv[1];
    if(datatype != "i" && datatype != "s"){
        cout << "Invalid datatype \"" << datatype << "\" (must be \"i\" or \"s\")" << endl;
        return -1;
    }

    ifstream index;
    index.open(argv[2]);
    if (!index.is_open()){
        cout << "Unable to open sort file" << endl;
        return -1;
    }

    ifstream input;
    input.open(argv[3]);
    if(!input.is_open()){
        cout << "Unable to open input file" << endl;
        return -1;
    }

    ofstream output;
    output.open(argv[4]);
    if(!output.is_open()){
        cout << "Unable to open output file" << endl;
        return -1;
    }

    int sort[2000];
    int sortCount = 0;

    int i_arr[2000];
    string s_arr[2000];
    int count = 0;

    while(!index.eof()){
        index >> sort[sortCount];
        sortCount++;
    }
    sortCount--;
    //cout << "DEBUG " << sortCount;

    if(datatype == "i"){
        while(!input.eof()){
            input >> i_arr[count];
            count++;
        }
        //cout << "INT " << count << endl;
    }
    if(datatype == "s"){
        while(!input.eof()){
            input >> s_arr[count];
            count++;
        }
        //cout << "STRING " << count << endl;
    }
    count--;

    if(datatype == "i"){
        MergeSort(i_arr, sort, sortCount, 0, count-1);
        for(int i = 0; i < count; i++){
            output << right << setw(10) << i_arr[i] << endl;
        }
    }
    if(datatype == "s"){
        MergeSortString(s_arr, sort, sortCount, 0, count-1);
        for(int i = 0; i < count; i++){
            output << s_arr[i] << endl;
        }
    }

    index.close();
    input.close();
    output.close();

    return 0;
}

bool CompareInts(int index[], int idx, int left, int right){
    //retruns true if lhs < rhs
    for (int i = 0; i < idx; i++){
        if(int(left / pow(10, index[i])) % 10 < int(right / pow(10,index[i])) % 10){
            return true;
        }
        else if (int(left / pow(10, index[i])) % 10 > int(right / pow(10,index[i])) % 10){
            return false;
        }
    }
    return true;
} 

void Merge(int numbers[], int index[], int idx, int i, int j, int k) {
    //i = left, j = mid, k = right
   int mergedSize;
   int mergePos;
   int left;
   int right;
   int* mergedNumbers = nullptr;

   mergePos = 0;
   mergedSize = k - i + 1;
   left = i;
   right = j + 1;
   mergedNumbers = new int[mergedSize];
   
   // Add smallest element from left or right partition to merged numbers
   while (left <= j && right <= k) {
      if (CompareInts(index,idx, numbers[left], numbers[right]) == true) {
         mergedNumbers[mergePos] = numbers[left];
         ++left;
      }
      else {
         mergedNumbers[mergePos] = numbers[right];
         ++right;
         
      }
      ++mergePos;
   }
   
   // If left partition is not empty, add remaining elements to merged numbers
   while (left <= j) {
      mergedNumbers[mergePos] = numbers[left];
      ++left;
      ++mergePos;
   }
   
   // If right partition is not empty, add remaining elements to merged numbers
   while (right <= k) {
      mergedNumbers[mergePos] = numbers[right];
      ++right;
      ++mergePos;
   }
   
   // Copy merge number back to numbers
   for (mergePos = 0; mergePos < mergedSize; ++mergePos) {
      numbers[i + mergePos] = mergedNumbers[mergePos];
   }
   delete[] mergedNumbers;
}

void MergeSort(int numbers[], int index[],int idx, int i, int k) {
   int mid;
   
   if (i < k) {
      mid = (i + k) / 2; 
      
      // Recursively sort left and right partitions
      MergeSort(numbers, index, idx, i, mid);
      MergeSort(numbers, index, idx, mid + 1, k);
      
      // Merge left and right partition in sorted order
      Merge(numbers, index, idx, i, mid, k);
   }
}

/////////////////////////////////////////////////////////////////////////////////

bool CompareStrings(int index[], int idx, string left, string right){
    for(int i = 0; i < idx; i++){
        //For when the index value is larger than the string size
        char ls = '\0';
        char rs = '\0';
        if(index[i] < left.size()){
            ls = left[index[i]];
        }
        if(index[i] < right.size()){
            rs = right[index[i]];
        }
        if(ls < rs){
            return true;
        }
        else if(ls > rs){
            return false;
        }
    }
    return true;

}

void MergeString(string strings[], int index[], int idx, int i, int j, int k){
   int mergedSize = 0;
   int mergePos = 0;
   int left = 0;
   int right = 0;
   string* mergedStrings = nullptr;

   mergePos = 0;
   mergedSize = k - i + 1;
   left = i;
   right = j + 1;
   mergedStrings = new string[mergedSize];

   while (left <= j && right <= k) {
      if (CompareStrings(index, idx, strings[left], strings[right]) == true){
         mergedStrings[mergePos] = strings[left];
         left++;
      }
      else {
         mergedStrings[mergePos] = strings[right];
         right++;
         
      }
      mergePos++;
   }

   while (left <= j) {
      mergedStrings[mergePos] = strings[left];
      left++;
      mergePos++;
   }

   while (right <= k) {
      mergedStrings[mergePos] = strings[right];
      right++;
      mergePos++;
   }

   for (mergePos = 0; mergePos < mergedSize; ++mergePos) {
        strings[i + mergePos] = mergedStrings[mergePos];
   }
   delete[] mergedStrings;
}

void MergeSortString(string strings[], int index[], int idx, int i, int k) {
   if (i < k) {
      int mid = (i + k) / 2;
      
      MergeSortString(strings, index, idx, i, mid);
      MergeSortString(strings, index, idx, mid + 1, k);
      
      MergeString(strings, index, idx, i, mid, k);
   }
}