/*
- The key is the index
- Use if statements to determine if int or string in the line to sort in the table
*/
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
using namespace std;

uint64_t djb2(string str) {
    const char *ptr = str.c_str();
    uint64_t hash = 5381;
    int c;
    while ((c = *ptr++)) {
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    return hash;
}

class Person {
public:
    string id;
    string first;
    string last;
    string email;
    string phone;
    string city;
    string state;
    string postalCode;
    void addData(string data, int dataSlot){
        switch (dataSlot)
        {
        case 0:
            id = data;
            break;
        case 1:
            first = data;
            break;
        case 2:
            last = data;
            break;
        case 3:
            email = data;
            break;
        case 4:
            phone = data;
            break;
        case 5:
            city = data;
            break;
        case 6:
            state = data;
            break;
        case 7:
            postalCode = data;
            break;
        
        default:
            break;
        }
    }
    string GetKeyValue(string key){
        if(key == "Id"){
            return id;
        }
        else if(key == "FirstName"){
            return first;
        }
        else if(key == "LastName"){
            return last;
        }
        else if(key == "Email"){
            return email;
        }
        else if(key == "Phone"){
            return phone;
        }
        else if(key == "City"){
            return city;
        }
        else if(key == "State"){
            return state;
        }
        else if(key == "PostalCode"){
            return postalCode;
        }
        else{
            return state;
        }
    }

};

class HashTable {
    public:
        string key;
        int size;
        int slots;
        vector<vector<Person> > vect;
        HashTable(int newSize, string newKey){
            key = newKey;
            size = newSize;
            slots = 0;
            vect.resize(size);
        }
        void print(){
            for(int i = 0; i < size; i++){
                if(vect[i].size() != 0){
                    cout << i << ": " << vect[i][0].GetKeyValue(key) <<" "<< "(" << vect[i].size() << ")," << endl;
                }
            }
        }
        void lookup(string keyVal){
            int i = 0;
            int bucketsProbed = 0;
            int bucket = djb2(keyVal) % size;
            while (bucketsProbed < size) {
                if (vect[bucket].size() == 0) {
                    cout << "No results" << endl;
                    return;
                }
                else if(vect[bucket].size() != 0 && keyVal == vect[bucket][0].GetKeyValue(key)){
                    // print all people in vect
                    cout << "Id,FirstName,LastName,Email,Phone,City,State,PostalCode" << endl;
                    for(int i = 0; i < vect[bucket].size(); i++){
                        cout << vect[bucket][i].id << "," << vect[bucket][i].first << "," 
                        << vect[bucket][i].last<< ","<< vect[bucket][i].email<<","<<vect[bucket][i].phone<<","
                        <<vect[bucket][i].city<<","<<vect[bucket][i].state<<","<<vect[bucket][i].postalCode<< endl;
                    }
                    return;

                }
                i = i + 1;
                bucket = ((djb2(keyVal) % size) + i*(43 - (djb2(keyVal) % 43))) %(size);
                bucketsProbed = bucketsProbed + 1;
            }
            return;
        }
        bool insert(Person newPerson){
            int i = 0;
            int bucketsProbed = 0;

            // Hash function determines initial bucket
            int bucket = djb2(newPerson.GetKeyValue(key)) % size;
            while (bucketsProbed < size) {
                // Insert item in next empty bucket 
                if (vect[bucket].size() == 0) {
                    vect[bucket].push_back(newPerson);//todo 2d insert
                    return true;
                }
                else if(vect[bucket][0].GetKeyValue(key) == newPerson.GetKeyValue(key)){
                    vect[bucket].push_back(newPerson);
                    return true;

                }
                // Increment i and recompute bucket index
                // c1 and c2 are programmer-defined constants for quadratic probing
                i = i + 1;
                bucket = ((djb2(newPerson.GetKeyValue(key)) % size) + i*(43 - (djb2(newPerson.GetKeyValue(key)) % 43))) %(size);

                // Increment number of buckets probed
                bucketsProbed = bucketsProbed + 1;
            }
            return false;
        }
};

void getVal(istream &is, string &str) {
    char ch;
    string line;

    is >> ch;
    getline(is, line);

    str = ch + line;
}

bool isValidKey(const string &key) {
    string validKeys[8] = { "Id", "FirstName", "LastName", "Email", "Phone", "City", "State", "PostalCode" };
    for (int i = 0; i < 8; i++) {
        if (key == validKeys[i]) {
            return true;
        }
    }
    return false;
}

int main(int argc, char **argv) {
    if (argc != 4) {
        cout << "Usage: ./a.out filename.txt table_size key" << endl;
        return 1;
    }

    string filename = argv[1];
    int tableSize = stoi(argv[2]);
    string key = argv[3];

    ifstream file(filename);
    if (!file) {
        cout << "Unable to open " << filename << endl;
        return 2;
    }

    if (!isValidKey(key)) {
        cout << "Invalid key: " << key << endl;
        return 3;
    }
   HashTable table(tableSize, key);
    // This is an example of how to retreive the tokens from the input file
    // You will need to modify this to fit your needs to build the hash table
    string line, token;
    getline(file, line); // consume header line
    
    while (getline(file, line)) { //goes over every line, where each line is a person
        int i = 0;
        Person newPerson;
        istringstream iss(line);
        while (getline(iss, token, '\t')) {//gets Person data 1 by 1
            //cout << token << "\t";
            newPerson.addData(token,i);
            i++;
        }
        table.insert(newPerson);
        //cout << endl;
    }

    cout << "Commands:" << endl << "\tprint" << endl << "\tlookup <key>" << endl << "\tquit" << endl;
    string cmd, val;
    while (1) {
        cout << endl << "Enter a command:" << endl;
        cin >> cmd;
        if (cmd == "quit") {
            break;
        }
        else if (cmd == "print") {
            table.print();
        }
        else if (cmd == "lookup") {
            getVal(cin, val);
            // lookup code here
            table.lookup(val);
        }
        else {
            getline(cin, val);
            cout << "Invalid command" << endl;
        }
    }

    return 0;
}
