/*
1- store data (3 arrays 1 for source, 1 for des, 1 for band)

2- output unqiues (make 4th array for unique) loop through source & des 
& check if string at index i source then des to see if it equals any string in array unique.

3-Then print out all strings in unique in uppercase (toUpper)
(1st Part)

4- Make combined array that combines source and des

5-Identify string(leaf) that show up in both source and des (for one item in source loop
through des to see if they equal add to 5th array & check to see if it isn't already in the 5th array (unique non leaf)
use the same function) Go back & forth between source and des looping through the list. (Ex: source[1] then des[1]...)

    -1 for loop that checks if source[i] shows up in des, & if it is in des check if it is already in unique non leaf array
    & if it isn't in there already add it in there. 
    Then in the same loop do the same thing for des[i]

6- Make 2 more arrays for bandTo & bandFrom, then for each non leaf loop through source and des array
then wherever that non leaf occurs add the bandwith to the corresponding arrays)

7- Then output into argv[2] each row so 1st row of (non leaf, bandTo, bandFrom, bandTo/bandFrom) then output all the following rows in that format.


*/
#include <iostream>
#include <string>
#include <fstream>
#include <ctype.h> 
#include <iomanip> 
using namespace std;

void upper(string &str);

int main(int argc, char *argv[]){
    string source[1001];
    string des[1001];
    int band[1001];
    ifstream infile;
    infile.open(argv[1]);
    int count = 0;

    while(!infile.eof()){
        infile >> source[count] >> des[count] >> band[count];
        upper(source[count]);
        upper(des[count]);
        count++;
    }
    infile.close();

    string combined[2000];
    string unique[2000];
    int uniqueSize = 0;

    for(int i = 0; i < count-1; i++){
        combined[2*i] = source[i];
        combined[2*i+1] = des[i];
    }

    
    for(int i = 0; i <count*2; i++){
       for(int j = 0; j <= uniqueSize; j++){
          if(j == uniqueSize){
             unique[j] = combined[i];
             uniqueSize++;
          }
          if(unique[j] == combined[i]){
             break;
          }
       }
    }

    ofstream outfile;
    outfile.open(argv[2]);
    
    for(int i = 0; i < uniqueSize; i++){
        outfile << unique[i] << endl;
    }

    int bandTo[2000] = {0};
    int bandFrom[2000] = {0};
    double avg;

    for(int i = 0; i < uniqueSize; i++){
        for(int j = 0; j < count-1; j++){
            if(unique[i] == source[j]){
                bandTo[i] += band[j];
            }
            if(unique[i] == des[j]){
                bandFrom[i] += band[j];
            }
        }
    }

    for(int i = 0; i < uniqueSize; i++){
        if(bandTo[i] != 0 && bandFrom[i] != 0){
            avg = double(bandFrom[i])/bandTo[i];
            outfile << fixed << setprecision(2) << unique[i] << " " <<bandTo[i] << " " << bandFrom[i]<< " " << avg << endl;
        }
    }
   
    outfile.close();

    return 0;
}

void upper(string &str){
    for(int i = 0; i < str.size(); i++){
        str[i] = toupper(str[i]);
    }
}