#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <map>

using namespace std;


class Node{
public:
    char ch;
    int freq;
    Node* left;
    Node* right;
    Node(char ch, int freq){
        this->ch = ch;
        this->freq = freq;
        this->left = nullptr;
        this->right = nullptr;
    }
};

class Compare {
public:
    // Compare the keys of the nodes
    // return true if x's key > y's key; false otherwise
    // bool operator()(T x, T y) where T is the type of the priority_queue
    bool operator()(Node* left, Node* right) {
        return left->freq > right->freq;
    }
};

Node* buildTree(const map<char, int>& freq) {
    priority_queue<Node*, vector<Node*>, Compare> minQueue;

    for (auto i = freq.begin(); i != freq.end(); i++) {
        minQueue.push(new Node(i->first, i->second));
    }

    while (minQueue.size() > 1) {
        Node* left = minQueue.top();
        minQueue.pop();
        Node* right = minQueue.top();
        minQueue.pop();

        Node* iNode = new Node('\0', left->freq + right->freq);
        iNode->left = left;
        iNode->right = right;

        minQueue.push(iNode);
    }

    return minQueue.top();
}

void generate(Node* root, string tree, map<char, pair<int, string>>& Table) {
    if (root) {
        if (root->ch != '\0') {
            Table[root->ch] = make_pair(root->freq, tree);
        }
        generate(root->left, tree + "0", Table);
        generate(root->right, tree + "1", Table);
    }
}

 
int main(int argc, char *argv[]) {
    string filename = argv[1];
    ifstream file(filename);
    if (!file) {
        cout << "Unable to open " << filename << endl;
        return 1;
    }

    map<char,int> frq; // creates a map (frq) of characters to ints 
    char ch;
    int uncompressed = 0;
    int compressed = 0;
    string encoded;
    while(file.get(ch)){
        frq[ch]+= 1;
    }
    
    // this is an example min priority_queue with type int
    // you will need to change the type to your node class
    // priority_queue<type, underlying_storage_container, comparer> minQueue;
    // priority_queue<T, vector<T>, QueueCompare> minQueue; where T is the type of the priority_queue

    Node* root = buildTree(frq);

    map<char, pair<int, string>> huff;
    generate(root, "", huff);


    for (auto i = huff.begin(); i != huff.end(); i++) {
        uncompressed += i->second.first * 8; //8 bits
        compressed += i->second.first * i->second.second.length();
    }

    cout << "Uncompressed length: " << uncompressed << "bits" << endl;
    cout << "Compressed length: " << compressed << "bits" << endl;
    cout << "CHAR|FREQ|CODE_LEN" << endl;


    for (auto i = huff.begin(); i != huff.end(); i++){
        cout << "'" << i->first << "'"<< "|" << i->second.first << "|" << i->second.second.length()<< endl;
    }
  
    file.close();
    return 0;
}
